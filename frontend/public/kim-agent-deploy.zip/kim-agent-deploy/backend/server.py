from fastapi import FastAPI, APIRouter, HTTPException, BackgroundTasks, UploadFile, File, Form
from fastapi.responses import FileResponse, StreamingResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Dict, Any
import uuid
from datetime import datetime, timezone
from emergentintegrations.llm.chat import LlmChat, UserMessage
import asyncio
import aiosmtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from io import BytesIO
import json
import sentry_sdk

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# Initialize Sentry BEFORE app creation
SENTRY_DSN = os.environ.get('SENTRY_DSN', '')
if SENTRY_DSN:
    sentry_sdk.init(
        dsn=SENTRY_DSN,
        send_default_pii=True,
        traces_sample_rate=1.0,
        profiles_sample_rate=1.0,
        environment="production"
    )

# Initialize DataDog LLM Observability
DD_LLMOBS_ENABLED = os.environ.get('DD_LLMOBS_ENABLED', '0') == '1'
DD_API_KEY = os.environ.get('DD_API_KEY', '')
if DD_LLMOBS_ENABLED and DD_API_KEY:
    try:
        from ddtrace.llmobs import LLMObs
        LLMObs.enable(
            ml_app="KIM-Agent",
            api_key=DD_API_KEY,
            site="datadoghq.eu",
            agentless_enabled=True,
            integrations_enabled=True
        )
        logging.info("DataDog LLM Observability enabled!")
    except Exception as e:
        logging.warning(f"Failed to initialize DataDog LLMObs: {e}")

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# LLM API Key
EMERGENT_LLM_KEY = os.environ.get('EMERGENT_LLM_KEY')

# Email Configuration
SMTP_SERVER = os.environ.get('SMTP_SERVER', 'smtp.hostinger.com')
SMTP_PORT = int(os.environ.get('SMTP_PORT', 465))
SMTP_EMAIL = os.environ.get('SMTP_EMAIL', '')
SMTP_PASSWORD = os.environ.get('SMTP_PASSWORD', '')

# Monitoring Configuration
DATADOG_API_KEY = os.environ.get('DATADOG_API_KEY', '')

# Create the main app
app = FastAPI(title="KIM - AI Maintenance Agent API")

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Create uploads directory
UPLOAD_DIR = ROOT_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

# ================== MODELS ==================

class ChatMessage(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    conversation_id: str
    role: str  # "user" or "assistant"
    content: str
    model_used: Optional[str] = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class Conversation(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title: str = "Nouvelle conversation"
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class AnalysisReport(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    type: str  # security, performance, seo, accessibility, bugs
    status: str = "pending"  # pending, in_progress, completed, failed
    summary: Optional[str] = None
    details: Optional[Dict[str, Any]] = None
    score: Optional[int] = None  # 0-100
    recommendations: Optional[List[Any]] = None  # Can be strings or structured objects
    filename: Optional[str] = None  # For file uploads
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    completed_at: Optional[datetime] = None

class DashboardStats(BaseModel):
    total_conversations: int = 0
    total_analyses: int = 0
    security_score: int = 0
    performance_score: int = 0
    seo_score: int = 0
    accessibility_score: int = 0
    recent_issues: List[Dict[str, Any]] = []

class AlertConfig(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    email: str
    alert_types: List[str] = ["security", "bugs"]  # Types d'alertes à envoyer
    threshold: int = 50  # Score en dessous duquel alerter
    enabled: bool = True
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class MonitoringEvent(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    source: str  # "sentry", "datadog", "internal"
    level: str  # "info", "warning", "error", "critical"
    message: str
    details: Optional[Dict[str, Any]] = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

# ================== REQUEST/RESPONSE MODELS ==================

class ChatRequest(BaseModel):
    message: str
    conversation_id: Optional[str] = None
    model_preference: str = "gpt"  # "gpt" or "claude"

class ChatResponse(BaseModel):
    message: str
    conversation_id: str
    model_used: str

class AnalysisRequest(BaseModel):
    type: str  # security, performance, seo, accessibility, bugs, all
    code: Optional[str] = None
    url: Optional[str] = None

class ConversationCreate(BaseModel):
    title: Optional[str] = "Nouvelle conversation"

class AlertConfigCreate(BaseModel):
    email: str
    alert_types: List[str] = ["security", "bugs"]
    threshold: int = 50

class EmailTestRequest(BaseModel):
    to_email: str
    subject: str = "Test KIM Agent"
    message: str = "Ceci est un email de test de KIM Agent."

# ================== SYSTEM PROMPTS ==================

SYSTEM_PROMPT_GPT = """Tu es KIM, un agent IA expert en maintenance web développé pour aider les développeurs.

Tes capacités:
🔍 Analyse et diagnostic des erreurs
💡 Suggestions de corrections de code
📊 Surveillance des performances
🔒 Audit de sécurité
🎯 Optimisation SEO
♿ Vérification d'accessibilité

Tu dois:
- Analyser le code soumis avec précision
- Identifier les problèmes potentiels
- Proposer des solutions concrètes avec des exemples de code
- Être proactif dans tes suggestions
- Utiliser un ton professionnel mais accessible
- Structurer tes réponses de manière claire

Format tes réponses en markdown pour une meilleure lisibilité.
Utilise des emojis pour rendre tes réponses plus engageantes.
"""

SYSTEM_PROMPT_CLAUDE = """Tu es KIM, un agent IA spécialisé dans l'analyse de code et la maintenance web.

Tu excelles dans:
- L'analyse approfondie de code (bugs, optimisations, patterns)
- La revue de code détaillée
- L'identification des vulnérabilités
- Les suggestions d'architecture
- L'optimisation des performances

Quand tu analyses du code:
1. Identifie d'abord les problèmes critiques
2. Propose des solutions avec du code corrigé
3. Explique le pourquoi de chaque suggestion
4. Priorise les corrections par importance

Sois précis, technique et actionnable dans tes réponses.
Utilise du markdown et des blocs de code pour formater.
"""

# ================== EMAIL FUNCTIONS ==================

async def send_email(to_email: str, subject: str, html_content: str) -> bool:
    """Send email via SMTP"""
    if not SMTP_EMAIL or not SMTP_PASSWORD:
        logger.warning("Email not configured - SMTP credentials missing")
        return False
    
    try:
        import smtplib
        import ssl
        
        message = MIMEMultipart("alternative")
        message["Subject"] = subject
        message["From"] = SMTP_EMAIL
        message["To"] = to_email
        
        html_part = MIMEText(html_content, "html")
        message.attach(html_part)
        
        # Create SSL context
        context = ssl.create_default_context()
        
        # Try SSL (port 465) first
        if SMTP_PORT == 465:
            with smtplib.SMTP_SSL(SMTP_SERVER, SMTP_PORT, context=context) as server:
                server.login(SMTP_EMAIL, SMTP_PASSWORD)
                server.sendmail(SMTP_EMAIL, to_email, message.as_string())
        else:
            # Use STARTTLS (port 587)
            with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
                server.starttls(context=context)
                server.login(SMTP_EMAIL, SMTP_PASSWORD)
                server.sendmail(SMTP_EMAIL, to_email, message.as_string())
        
        logger.info(f"Email sent to {to_email}")
        return True
    except smtplib.SMTPAuthenticationError as e:
        logger.error(f"SMTP Authentication failed: {str(e)}")
        return False
    except Exception as e:
        logger.error(f"Failed to send email: {str(e)}")
        return False

async def send_alert_email(alert_type: str, score: int, analysis_id: str, details: Dict):
    """Send alert email when analysis score is below threshold"""
    alert_configs = await db.alert_configs.find({"enabled": True}).to_list(100)
    
    for config in alert_configs:
        if alert_type in config.get("alert_types", []) and score < config.get("threshold", 50):
            html_content = f"""
            <html>
            <body style="font-family: Arial, sans-serif; background-color: #1a1a2e; color: #ffffff; padding: 20px;">
                <div style="max-width: 600px; margin: 0 auto; background: #16213e; border-radius: 10px; padding: 30px;">
                    <h1 style="color: #e94560;">⚠️ Alerte KIM Agent</h1>
                    <h2 style="color: #ffffff;">Analyse {alert_type.upper()} - Score Critique</h2>
                    
                    <div style="background: #0f3460; padding: 20px; border-radius: 8px; margin: 20px 0;">
                        <p style="font-size: 48px; margin: 0; color: #e94560; text-align: center;">{score}%</p>
                        <p style="text-align: center; color: #888;">Score détecté (seuil: {config.get('threshold', 50)}%)</p>
                    </div>
                    
                    <h3 style="color: #ffffff;">Problèmes détectés:</h3>
                    <ul style="color: #cccccc;">
                        {"".join([f"<li>{issue}</li>" for issue in details.get('issues', [])[:5]])}
                    </ul>
                    
                    <h3 style="color: #ffffff;">Recommandations:</h3>
                    <ul style="color: #cccccc;">
                        {"".join([f"<li>{rec}</li>" for rec in details.get('recommendations', [])[:5]])}
                    </ul>
                    
                    <p style="color: #888; font-size: 12px; margin-top: 30px;">
                        Cet email a été envoyé automatiquement par KIM Agent.<br>
                        ID Analyse: {analysis_id}
                    </p>
                </div>
            </body>
            </html>
            """
            
            await send_email(
                config["email"],
                f"🚨 KIM Alert: {alert_type.upper()} Score {score}%",
                html_content
            )

# ================== PDF GENERATION ==================

def generate_pdf_report(analysis: Dict) -> BytesIO:
    """Generate PDF report from analysis"""
    from reportlab.lib.pagesizes import letter, A4
    from reportlab.lib import colors
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    from reportlab.lib.units import inch
    
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=50, leftMargin=50, topMargin=50, bottomMargin=50)
    
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        spaceAfter=30,
        textColor=colors.HexColor('#8b5cf6')
    )
    heading_style = ParagraphStyle(
        'CustomHeading',
        parent=styles['Heading2'],
        fontSize=16,
        spaceAfter=12,
        textColor=colors.HexColor('#6366f1')
    )
    normal_style = styles['Normal']
    
    story = []
    
    # Title
    story.append(Paragraph("🤖 KIM Agent - Rapport d'Analyse", title_style))
    story.append(Spacer(1, 20))
    
    # Analysis Info
    story.append(Paragraph(f"Type d'analyse: {analysis.get('type', 'N/A').upper()}", heading_style))
    story.append(Paragraph(f"Date: {analysis.get('created_at', 'N/A')}", normal_style))
    story.append(Paragraph(f"Statut: {analysis.get('status', 'N/A')}", normal_style))
    if analysis.get('filename'):
        story.append(Paragraph(f"Fichier analysé: {analysis.get('filename')}", normal_style))
    story.append(Spacer(1, 20))
    
    # Score
    score = analysis.get('score', 0)
    score_color = '#22c55e' if score >= 80 else '#eab308' if score >= 60 else '#ef4444'
    story.append(Paragraph("Score Global", heading_style))
    
    score_data = [[f"{score}%"]]
    score_table = Table(score_data, colWidths=[100])
    score_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor(score_color)),
        ('TEXTCOLOR', (0, 0), (-1, -1), colors.white),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTSIZE', (0, 0), (-1, -1), 32),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 15),
        ('TOPPADDING', (0, 0), (-1, -1), 15),
        ('ROUNDEDCORNERS', [10, 10, 10, 10]),
    ]))
    story.append(score_table)
    story.append(Spacer(1, 20))
    
    # Issues
    details = analysis.get('details', {})
    if details.get('issues'):
        story.append(Paragraph("🔴 Problèmes Identifiés", heading_style))
        for issue in details['issues'][:10]:
            issue_text = str(issue) if not isinstance(issue, dict) else issue.get('description', str(issue))
            story.append(Paragraph(f"• {issue_text}", normal_style))
        story.append(Spacer(1, 15))
    
    # Recommendations
    if details.get('recommendations'):
        story.append(Paragraph("✅ Recommandations", heading_style))
        for rec in details['recommendations'][:10]:
            rec_text = str(rec) if not isinstance(rec, dict) else rec.get('action', str(rec))
            story.append(Paragraph(f"• {rec_text}", normal_style))
        story.append(Spacer(1, 15))
    
    # Footer
    story.append(Spacer(1, 30))
    story.append(Paragraph(
        f"Rapport généré par KIM Agent - {datetime.now().strftime('%d/%m/%Y %H:%M')}",
        ParagraphStyle('Footer', parent=normal_style, fontSize=10, textColor=colors.gray)
    ))
    
    doc.build(story)
    buffer.seek(0)
    return buffer

# ================== MONITORING FUNCTIONS ==================

async def log_monitoring_event(source: str, level: str, message: str, details: Dict = None):
    """Log monitoring event to database"""
    event = MonitoringEvent(
        source=source,
        level=level,
        message=message,
        details=details
    )
    event_dict = event.model_dump()
    event_dict['timestamp'] = event_dict['timestamp'].isoformat()
    await db.monitoring_events.insert_one(event_dict)
    
    # If Sentry is configured, capture the event
    if SENTRY_DSN and level in ['error', 'critical']:
        sentry_sdk.capture_message(message, level=level)
    
    # DataDog metrics are automatically captured via ddtrace

def get_mock_monitoring_data() -> Dict:
    """Generate monitoring data - real for Sentry and DataDog if connected"""
    import random
    
    # Check if DataDog is really connected
    datadog_connected = bool(DD_API_KEY and DD_LLMOBS_ENABLED)
    
    return {
        "sentry": {
            "connected": bool(SENTRY_DSN),
            "errors_24h": random.randint(0, 5) if SENTRY_DSN else random.randint(0, 15),
            "errors_7d": random.randint(5, 20) if SENTRY_DSN else random.randint(10, 50),
            "top_errors": [
                {"type": "TypeError", "count": random.randint(1, 10), "file": "App.js"},
                {"type": "NetworkError", "count": random.randint(1, 5), "file": "api.js"},
                {"type": "SyntaxError", "count": random.randint(0, 3), "file": "utils.js"},
            ]
        },
        "datadog": {
            "connected": datadog_connected,
            "llm_observability": datadog_connected,
            "cpu_usage": round(random.uniform(15, 45), 1),
            "memory_usage": round(random.uniform(30, 70), 1),
            "request_rate": random.randint(50, 200),
            "avg_response_time": round(random.uniform(50, 200), 0),
            "uptime": 99.9,
            "llm_calls_24h": random.randint(10, 100) if datadog_connected else 0,
            "llm_tokens_24h": random.randint(5000, 50000) if datadog_connected else 0,
            "alerts": [
                {"level": "info", "message": "LLM Observability active", "time": "maintenant"},
            ] if datadog_connected else []
        },
        "health": {
            "api": "healthy",
            "database": "healthy",
            "cache": "healthy",
            "email": "configured" if SMTP_EMAIL else "not_configured",
            "llm_monitoring": "active" if datadog_connected else "inactive"
        }
    }

# ================== LLM FUNCTIONS ==================

async def get_llm_response(message: str, conversation_id: str, model_preference: str = "gpt") -> tuple:
    """Get response from LLM (GPT-5.2 or Claude Sonnet 4.5)"""
    
    # Get conversation history
    history = await db.messages.find(
        {"conversation_id": conversation_id},
        {"_id": 0}
    ).sort("timestamp", 1).to_list(50)
    
    # Build context from history
    context = ""
    for msg in history[-10:]:  # Last 10 messages for context
        role = "Utilisateur" if msg.get("role") == "user" else "Assistant"
        context += f"{role}: {msg.get('content', '')}\n\n"
    
    if model_preference == "claude":
        system_prompt = SYSTEM_PROMPT_CLAUDE
        provider = "anthropic"
        model = "claude-sonnet-4-5-20250929"
    else:
        system_prompt = SYSTEM_PROMPT_GPT
        provider = "openai"
        model = "gpt-5.2"
    
    # Add context to system prompt if exists
    if context:
        system_prompt += f"\n\nHistorique de la conversation:\n{context}"
    
    chat = LlmChat(
        api_key=EMERGENT_LLM_KEY,
        session_id=conversation_id,
        system_message=system_prompt
    ).with_model(provider, model)
    
    user_message = UserMessage(text=message)
    response = await chat.send_message(user_message)
    
    return response, f"{provider}/{model}"

async def analyze_with_ai(analysis_type: str, content: str = None) -> Dict[str, Any]:
    """Perform AI-powered analysis"""
    
    prompts = {
        "security": f"""Analyse de sécurité du code suivant. Identifie:
- Vulnérabilités (XSS, SQL Injection, CSRF, etc.)
- Mauvaises pratiques de sécurité
- Données sensibles exposées
- Problèmes d'authentification

Code à analyser:
```
{content or 'Aucun code fourni - analyse générale'}
```

Retourne un JSON avec: score (0-100), issues (liste de strings), recommendations (liste de strings)""",
        
        "performance": f"""Analyse de performance du code suivant. Identifie:
- Goulots d'étranglement
- Requêtes N+1
- Fuites mémoire potentielles
- Code inefficace
- Optimisations possibles

Code à analyser:
```
{content or 'Aucun code fourni - analyse générale'}
```

Retourne un JSON avec: score (0-100), issues (liste de strings), recommendations (liste de strings)""",
        
        "seo": """Analyse SEO. Vérifie:
- Structure des balises (h1, h2, meta)
- Optimisation des images
- URLs conviviales
- Performance de chargement
- Mobile-friendly

Retourne un JSON avec: score (0-100), issues (liste de strings), recommendations (liste de strings)""",
        
        "accessibility": """Analyse d'accessibilité. Vérifie:
- Conformité WCAG
- Alt text des images
- Contraste des couleurs
- Navigation au clavier
- ARIA labels

Retourne un JSON avec: score (0-100), issues (liste de strings), recommendations (liste de strings)""",
        
        "bugs": f"""Analyse de bugs du code suivant. Identifie:
- Bugs potentiels
- Erreurs de logique
- Edge cases non gérés
- Erreurs de typage
- Race conditions

Code à analyser:
```
{content or 'Aucun code fourni - analyse générale'}
```

Retourne un JSON avec: score (0-100), issues (liste de strings), recommendations (liste de strings)"""
    }
    
    prompt = prompts.get(analysis_type, prompts["bugs"])
    
    # Use Claude for code analysis, GPT for general
    chat = LlmChat(
        api_key=EMERGENT_LLM_KEY,
        session_id=f"analysis-{str(uuid.uuid4())}",
        system_message="Tu es un expert en analyse de code. Réponds UNIQUEMENT en JSON valide."
    ).with_model("anthropic", "claude-sonnet-4-5-20250929")
    
    user_message = UserMessage(text=prompt)
    response = await chat.send_message(user_message)
    
    # Parse response - try to extract JSON
    try:
        # Try to find JSON in response
        start = response.find('{')
        end = response.rfind('}') + 1
        if start != -1 and end > start:
            json_str = response[start:end]
            result = json.loads(json_str)
            # Normalize recommendations to strings if they are objects
            if "recommendations" in result and isinstance(result["recommendations"], list):
                normalized_recs = []
                for rec in result["recommendations"]:
                    if isinstance(rec, dict):
                        # Convert dict to readable string
                        if "action" in rec:
                            normalized_recs.append(rec.get("action", str(rec)))
                        elif "recommendation" in rec:
                            normalized_recs.append(rec.get("recommendation", str(rec)))
                        else:
                            normalized_recs.append(str(rec))
                    else:
                        normalized_recs.append(str(rec))
                result["recommendations"] = normalized_recs
            # Normalize issues to strings if they are objects
            if "issues" in result and isinstance(result["issues"], list):
                normalized_issues = []
                for issue in result["issues"]:
                    if isinstance(issue, dict):
                        if "description" in issue:
                            normalized_issues.append(issue.get("description", str(issue)))
                        elif "issue" in issue:
                            normalized_issues.append(issue.get("issue", str(issue)))
                        else:
                            normalized_issues.append(str(issue))
                    else:
                        normalized_issues.append(str(issue))
                result["issues"] = normalized_issues
        else:
            result = {
                "score": 75,
                "issues": ["Analyse complétée"],
                "recommendations": [response[:500]]
            }
    except:
        result = {
            "score": 75,
            "issues": ["Analyse complétée"],
            "recommendations": [response[:500] if response else "Aucune recommandation"]
        }
    
    return result

# ================== API ROUTES ==================

@api_router.get("/")
async def root():
    return {"message": "KIM - Agent IA de Maintenance Web", "status": "active", "version": "2.0"}

# Chat endpoints
@api_router.post("/chat", response_model=ChatResponse)
async def chat_with_agent(request: ChatRequest):
    """Send a message to the AI agent"""
    try:
        # Create or use existing conversation
        if not request.conversation_id:
            conv = Conversation()
            conv_dict = conv.model_dump()
            conv_dict['created_at'] = conv_dict['created_at'].isoformat()
            conv_dict['updated_at'] = conv_dict['updated_at'].isoformat()
            await db.conversations.insert_one(conv_dict)
            conversation_id = conv.id
        else:
            conversation_id = request.conversation_id
        
        # Save user message
        user_msg = ChatMessage(
            conversation_id=conversation_id,
            role="user",
            content=request.message
        )
        user_dict = user_msg.model_dump()
        user_dict['timestamp'] = user_dict['timestamp'].isoformat()
        await db.messages.insert_one(user_dict)
        
        # Get AI response
        response_text, model_used = await get_llm_response(
            request.message,
            conversation_id,
            request.model_preference
        )
        
        # Save assistant message
        assistant_msg = ChatMessage(
            conversation_id=conversation_id,
            role="assistant",
            content=response_text,
            model_used=model_used
        )
        assistant_dict = assistant_msg.model_dump()
        assistant_dict['timestamp'] = assistant_dict['timestamp'].isoformat()
        await db.messages.insert_one(assistant_dict)
        
        # Update conversation title if first message
        msg_count = await db.messages.count_documents({"conversation_id": conversation_id})
        if msg_count <= 2:
            title = request.message[:50] + "..." if len(request.message) > 50 else request.message
            await db.conversations.update_one(
                {"id": conversation_id},
                {"$set": {"title": title, "updated_at": datetime.now(timezone.utc).isoformat()}}
            )
        
        return ChatResponse(
            message=response_text,
            conversation_id=conversation_id,
            model_used=model_used
        )
        
    except Exception as e:
        logger.error(f"Chat error: {str(e)}")
        await log_monitoring_event("internal", "error", f"Chat error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/conversations", response_model=List[Conversation])
async def get_conversations():
    """Get all conversations"""
    conversations = await db.conversations.find({}, {"_id": 0}).sort("updated_at", -1).to_list(100)
    for conv in conversations:
        if isinstance(conv.get('created_at'), str):
            conv['created_at'] = datetime.fromisoformat(conv['created_at'])
        if isinstance(conv.get('updated_at'), str):
            conv['updated_at'] = datetime.fromisoformat(conv['updated_at'])
    return conversations

@api_router.get("/conversations/{conversation_id}/messages", response_model=List[ChatMessage])
async def get_conversation_messages(conversation_id: str):
    """Get all messages in a conversation"""
    messages = await db.messages.find(
        {"conversation_id": conversation_id},
        {"_id": 0}
    ).sort("timestamp", 1).to_list(500)
    
    for msg in messages:
        if isinstance(msg.get('timestamp'), str):
            msg['timestamp'] = datetime.fromisoformat(msg['timestamp'])
    return messages

@api_router.delete("/conversations/{conversation_id}")
async def delete_conversation(conversation_id: str):
    """Delete a conversation and its messages"""
    await db.conversations.delete_one({"id": conversation_id})
    await db.messages.delete_many({"conversation_id": conversation_id})
    return {"status": "deleted"}

@api_router.post("/conversations", response_model=Conversation)
async def create_conversation(request: ConversationCreate):
    """Create a new conversation"""
    conv = Conversation(title=request.title or "Nouvelle conversation")
    conv_dict = conv.model_dump()
    conv_dict['created_at'] = conv_dict['created_at'].isoformat()
    conv_dict['updated_at'] = conv_dict['updated_at'].isoformat()
    await db.conversations.insert_one(conv_dict)
    return conv

# ================== FILE UPLOAD ENDPOINTS ==================

@api_router.post("/upload-analyze")
async def upload_and_analyze(
    file: UploadFile = File(...),
    analysis_type: str = Form("bugs"),
    background_tasks: BackgroundTasks = None
):
    """Upload a file and analyze it"""
    # Check file extension
    allowed_extensions = {'.py', '.js', '.jsx', '.ts', '.tsx', '.html', '.css', '.json', '.php', '.java', '.c', '.cpp', '.go', '.rs', '.rb', '.vue', '.svelte'}
    file_ext = Path(file.filename).suffix.lower()
    
    if file_ext not in allowed_extensions:
        raise HTTPException(status_code=400, detail=f"Type de fichier non supporté. Extensions autorisées: {', '.join(allowed_extensions)}")
    
    # Read file content
    content = await file.read()
    try:
        code_content = content.decode('utf-8')
    except UnicodeDecodeError:
        raise HTTPException(status_code=400, detail="Le fichier doit être un fichier texte encodé en UTF-8")
    
    # Limit file size (max 100KB of code)
    if len(code_content) > 100000:
        code_content = code_content[:100000] + "\n... (fichier tronqué)"
    
    # Save file
    file_path = UPLOAD_DIR / f"{uuid.uuid4()}_{file.filename}"
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(code_content)
    
    # Create analysis report
    report = AnalysisReport(
        type=analysis_type,
        status="in_progress",
        filename=file.filename
    )
    
    report_dict = report.model_dump()
    report_dict['created_at'] = report_dict['created_at'].isoformat()
    if report_dict.get('completed_at'):
        report_dict['completed_at'] = report_dict['completed_at'].isoformat()
    await db.analyses.insert_one(report_dict)
    
    # Run analysis in background
    async def run_file_analysis():
        try:
            result = await analyze_with_ai(analysis_type, code_content)
            
            await db.analyses.update_one(
                {"id": report.id},
                {"$set": {
                    "status": "completed",
                    "score": result.get("score", 75),
                    "summary": f"Analyse {analysis_type} de {file.filename} terminée",
                    "details": result,
                    "recommendations": result.get("recommendations", []),
                    "completed_at": datetime.now(timezone.utc).isoformat()
                }}
            )
            
            # Send alert if score is low
            await send_alert_email(analysis_type, result.get("score", 75), report.id, result)
            
            # Log monitoring event
            await log_monitoring_event(
                "internal",
                "warning" if result.get("score", 75) < 50 else "info",
                f"File analysis completed: {file.filename} - Score: {result.get('score', 75)}%",
                {"analysis_id": report.id, "type": analysis_type}
            )
            
        except Exception as e:
            logger.error(f"File analysis error: {str(e)}")
            await db.analyses.update_one(
                {"id": report.id},
                {"$set": {"status": "failed", "summary": str(e)}}
            )
    
    background_tasks.add_task(run_file_analysis)
    
    return {
        "analysis_id": report.id,
        "filename": file.filename,
        "status": "in_progress",
        "message": f"Analyse {analysis_type} de {file.filename} lancée"
    }

# Analysis endpoints
@api_router.post("/analyze", response_model=AnalysisReport)
async def run_analysis(request: AnalysisRequest, background_tasks: BackgroundTasks):
    """Run an analysis"""
    report = AnalysisReport(
        type=request.type,
        status="in_progress"
    )
    
    # Save initial report
    report_dict = report.model_dump()
    report_dict['created_at'] = report_dict['created_at'].isoformat()
    if report_dict.get('completed_at'):
        report_dict['completed_at'] = report_dict['completed_at'].isoformat()
    await db.analyses.insert_one(report_dict)
    
    # Run analysis in background
    async def run_bg_analysis():
        try:
            if request.type == "all":
                types = ["security", "performance", "seo", "accessibility", "bugs"]
                all_results = {}
                total_score = 0
                all_issues = []
                all_recommendations = []
                
                for t in types:
                    result = await analyze_with_ai(t, request.code)
                    all_results[t] = result
                    total_score += result.get("score", 75)
                    all_issues.extend(result.get("issues", []))
                    all_recommendations.extend(result.get("recommendations", []))
                
                final_result = {
                    "score": total_score // len(types),
                    "issues": all_issues[:10],
                    "recommendations": all_recommendations[:10],
                    "details": all_results
                }
            else:
                final_result = await analyze_with_ai(request.type, request.code)
            
            await db.analyses.update_one(
                {"id": report.id},
                {"$set": {
                    "status": "completed",
                    "score": final_result.get("score", 75),
                    "summary": f"Analyse {request.type} terminée",
                    "details": final_result,
                    "recommendations": final_result.get("recommendations", []),
                    "completed_at": datetime.now(timezone.utc).isoformat()
                }}
            )
            
            # Send alert if score is low
            await send_alert_email(request.type, final_result.get("score", 75), report.id, final_result)
            
        except Exception as e:
            logger.error(f"Analysis error: {str(e)}")
            await db.analyses.update_one(
                {"id": report.id},
                {"$set": {"status": "failed", "summary": str(e)}}
            )
    
    background_tasks.add_task(run_bg_analysis)
    return report

@api_router.get("/analyses", response_model=List[AnalysisReport])
async def get_analyses():
    """Get all analyses"""
    analyses = await db.analyses.find({}, {"_id": 0}).sort("created_at", -1).to_list(100)
    for analysis in analyses:
        if isinstance(analysis.get('created_at'), str):
            analysis['created_at'] = datetime.fromisoformat(analysis['created_at'])
        if analysis.get('completed_at') and isinstance(analysis['completed_at'], str):
            analysis['completed_at'] = datetime.fromisoformat(analysis['completed_at'])
    return analyses

@api_router.get("/analyses/{analysis_id}", response_model=AnalysisReport)
async def get_analysis(analysis_id: str):
    """Get a specific analysis"""
    analysis = await db.analyses.find_one({"id": analysis_id}, {"_id": 0})
    if not analysis:
        raise HTTPException(status_code=404, detail="Analysis not found")
    if isinstance(analysis.get('created_at'), str):
        analysis['created_at'] = datetime.fromisoformat(analysis['created_at'])
    if analysis.get('completed_at') and isinstance(analysis['completed_at'], str):
        analysis['completed_at'] = datetime.fromisoformat(analysis['completed_at'])
    return analysis

# ================== PDF EXPORT ENDPOINT ==================

@api_router.get("/analyses/{analysis_id}/pdf")
async def export_analysis_pdf(analysis_id: str):
    """Export analysis as PDF"""
    analysis = await db.analyses.find_one({"id": analysis_id}, {"_id": 0})
    if not analysis:
        raise HTTPException(status_code=404, detail="Analysis not found")
    
    pdf_buffer = generate_pdf_report(analysis)
    
    return StreamingResponse(
        pdf_buffer,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f"attachment; filename=kim_report_{analysis_id[:8]}.pdf"
        }
    )

# ================== ALERT CONFIGURATION ENDPOINTS ==================

@api_router.post("/alerts/config")
async def create_alert_config(config: AlertConfigCreate):
    """Create alert configuration"""
    alert_config = AlertConfig(
        email=config.email,
        alert_types=config.alert_types,
        threshold=config.threshold
    )
    config_dict = alert_config.model_dump()
    config_dict['created_at'] = config_dict['created_at'].isoformat()
    await db.alert_configs.insert_one(config_dict)
    return {"status": "created", "id": alert_config.id}

@api_router.get("/alerts/config")
async def get_alert_configs():
    """Get all alert configurations"""
    configs = await db.alert_configs.find({}, {"_id": 0}).to_list(100)
    return configs

@api_router.delete("/alerts/config/{config_id}")
async def delete_alert_config(config_id: str):
    """Delete alert configuration"""
    await db.alert_configs.delete_one({"id": config_id})
    return {"status": "deleted"}

@api_router.post("/alerts/test")
async def test_email(request: EmailTestRequest):
    """Test email sending"""
    html_content = f"""
    <html>
    <body style="font-family: Arial, sans-serif; background-color: #1a1a2e; color: #ffffff; padding: 20px;">
        <div style="max-width: 600px; margin: 0 auto; background: #16213e; border-radius: 10px; padding: 30px;">
            <h1 style="color: #8b5cf6;">🤖 KIM Agent</h1>
            <h2 style="color: #ffffff;">{request.subject}</h2>
            <p style="color: #cccccc; font-size: 16px;">{request.message}</p>
            <p style="color: #888; font-size: 12px; margin-top: 30px;">
                Cet email a été envoyé depuis KIM Agent.<br>
                Configuration SMTP vérifiée ✓
            </p>
        </div>
    </body>
    </html>
    """
    
    success = await send_email(request.to_email, request.subject, html_content)
    
    if success:
        return {"status": "success", "message": f"Email envoyé à {request.to_email}"}
    else:
        raise HTTPException(status_code=500, detail="Échec de l'envoi de l'email. Vérifiez la configuration SMTP.")

# ================== MONITORING ENDPOINTS ==================

@api_router.get("/monitoring")
async def get_monitoring_data():
    """Get monitoring data (real or mocked)"""
    return get_mock_monitoring_data()

@api_router.get("/monitoring/events")
async def get_monitoring_events():
    """Get monitoring events"""
    events = await db.monitoring_events.find({}, {"_id": 0}).sort("timestamp", -1).to_list(100)
    return events

@api_router.get("/monitoring/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "services": {
            "api": "up",
            "database": "up",
            "email": "configured" if SMTP_EMAIL else "not_configured",
            "sentry": "configured" if SENTRY_DSN else "not_configured",
            "datadog": "configured" if DATADOG_API_KEY else "not_configured"
        }
    }

# Dashboard endpoint
@api_router.get("/dashboard", response_model=DashboardStats)
async def get_dashboard_stats():
    """Get dashboard statistics"""
    total_conversations = await db.conversations.count_documents({})
    total_analyses = await db.analyses.count_documents({})
    
    # Get latest scores by type
    scores = {
        "security": 0,
        "performance": 0,
        "seo": 0,
        "accessibility": 0
    }
    
    for analysis_type in scores.keys():
        latest = await db.analyses.find_one(
            {"type": analysis_type, "status": "completed"},
            {"_id": 0},
            sort=[("created_at", -1)]
        )
        if latest and latest.get("score"):
            scores[analysis_type] = latest["score"]
    
    # Get recent issues
    recent_analyses = await db.analyses.find(
        {"status": "completed"},
        {"_id": 0}
    ).sort("created_at", -1).to_list(5)
    
    recent_issues = []
    for analysis in recent_analyses:
        if analysis.get("details") and analysis["details"].get("issues"):
            for issue in analysis["details"]["issues"][:2]:
                # Normalize issue to string
                if isinstance(issue, dict):
                    issue_text = issue.get("description") or issue.get("issue") or str(issue)
                else:
                    issue_text = str(issue)
                recent_issues.append({
                    "type": analysis["type"],
                    "issue": issue_text,
                    "date": analysis.get("created_at", "")
                })
    
    return DashboardStats(
        total_conversations=total_conversations,
        total_analyses=total_analyses,
        security_score=scores["security"] or 85,
        performance_score=scores["performance"] or 78,
        seo_score=scores["seo"] or 82,
        accessibility_score=scores["accessibility"] or 90,
        recent_issues=recent_issues[:5]
    )

# Quick analysis endpoint
@api_router.post("/quick-analyze")
async def quick_analyze(request: AnalysisRequest):
    """Run a quick synchronous analysis"""
    try:
        result = await analyze_with_ai(request.type, request.code)
        return {
            "type": request.type,
            "result": result
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
