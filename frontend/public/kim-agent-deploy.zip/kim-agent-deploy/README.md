# 🤖 KIM Agent - Guide de Déploiement

Agent IA de maintenance web avec GPT-5.2 et Claude Sonnet 4.5.

## 📋 Prérequis

- **Serveur** : VPS Linux (Ubuntu 20.04+ recommandé)
- **Python** : 3.10+
- **Node.js** : 18+
- **MongoDB** : 4.4+
- **RAM** : 2GB minimum
- **Espace disque** : 5GB minimum

## 🚀 Installation Rapide

### 1. Cloner ou copier les fichiers

```bash
# Créer le dossier
mkdir -p /var/www/kim-agent
cd /var/www/kim-agent

# Copier les fichiers backend et frontend
```

### 2. Installer les dépendances Backend

```bash
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 3. Configurer l'environnement Backend

```bash
# Éditer le fichier .env
nano backend/.env
```

Contenu de `.env` :
```
MONGO_URL="mongodb://localhost:27017"
DB_NAME="kim_agent"
CORS_ORIGINS="https://votre-domaine.com"
EMERGENT_LLM_KEY=votre_cle_emergent

# Sentry (optionnel)
SENTRY_DSN=votre_dsn_sentry

# DataDog (optionnel)
DD_API_KEY=votre_cle_datadog
DD_SITE=datadoghq.eu
DD_LLMOBS_ENABLED=1
DD_LLMOBS_ML_APP=KIM-Agent
```

### 4. Installer les dépendances Frontend

```bash
cd frontend
yarn install
```

### 5. Configurer le Frontend

```bash
# Éditer frontend/.env
nano frontend/.env
```

Contenu :
```
REACT_APP_BACKEND_URL=https://votre-domaine.com/api
```

### 6. Build du Frontend pour production

```bash
cd frontend
yarn build
```

### 7. Lancer le Backend

Avec **systemd** :

```bash
# Créer le service
sudo nano /etc/systemd/system/kim-agent.service
```

Contenu :
```ini
[Unit]
Description=KIM Agent Backend
After=network.target mongodb.service

[Service]
User=www-data
WorkingDirectory=/var/www/kim-agent/backend
Environment="PATH=/var/www/kim-agent/backend/venv/bin"
ExecStart=/var/www/kim-agent/backend/venv/bin/uvicorn server:app --host 0.0.0.0 --port 8001
Restart=always

[Install]
WantedBy=multi-user.target
```

Activer :
```bash
sudo systemctl daemon-reload
sudo systemctl enable kim-agent
sudo systemctl start kim-agent
```

### 8. Configuration Nginx

```nginx
server {
    listen 80;
    server_name votre-domaine.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name votre-domaine.com;

    ssl_certificate /etc/letsencrypt/live/votre-domaine.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/votre-domaine.com/privkey.pem;

    # Frontend
    location / {
        root /var/www/kim-agent/frontend/build;
        try_files $uri $uri/ /index.html;
    }

    # Backend API
    location /api {
        proxy_pass http://127.0.0.1:8001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

### 9. Certificat SSL (Let's Encrypt)

```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d votre-domaine.com
```

## ✅ Vérification

```bash
# Vérifier le backend
curl https://votre-domaine.com/api/

# Doit retourner:
# {"message":"KIM - Agent IA de Maintenance Web","status":"active","version":"2.0"}
```

## 🔑 Clés API nécessaires

1. **Emergent LLM Key** : Pour GPT-5.2 et Claude 4.5
2. **Sentry DSN** (optionnel) : Pour le monitoring des erreurs
3. **DataDog API Key** (optionnel) : Pour le monitoring LLM

## 📞 Support

KIM Agent créé par l'équipe Emergent.
