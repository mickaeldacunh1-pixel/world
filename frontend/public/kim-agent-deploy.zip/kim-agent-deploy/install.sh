#!/bin/bash

echo "🤖 Installation de KIM Agent"
echo "============================="

# Vérifier si on est root
if [ "$EUID" -ne 0 ]; then
    echo "❌ Veuillez exécuter en tant que root (sudo)"
    exit 1
fi

# Mettre à jour le système
echo "📦 Mise à jour du système..."
apt update && apt upgrade -y

# Installer les dépendances
echo "📦 Installation des dépendances..."
apt install -y python3 python3-pip python3-venv nodejs npm nginx certbot python3-certbot-nginx

# Installer MongoDB
echo "📦 Installation de MongoDB..."
wget -qO - https://www.mongodb.org/static/pgp/server-6.0.asc | apt-key add -
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu focal/mongodb-org/6.0 multiverse" | tee /etc/apt/sources.list.d/mongodb-org-6.0.list
apt update
apt install -y mongodb-org
systemctl start mongod
systemctl enable mongod

# Installer Yarn
echo "📦 Installation de Yarn..."
npm install -g yarn

echo ""
echo "✅ Dépendances installées !"
echo ""
echo "Prochaines étapes :"
echo "1. Copiez les fichiers backend/ et frontend/ vers /var/www/kim-agent/"
echo "2. Configurez les fichiers .env"
echo "3. Suivez le README.md pour finaliser l'installation"
