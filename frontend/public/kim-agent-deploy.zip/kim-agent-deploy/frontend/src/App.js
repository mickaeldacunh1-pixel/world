import { useState, useEffect, useRef, useCallback } from "react";
import * as Sentry from "@sentry/react";
import "@/App.css";
import axios from "axios";
import { Send, Bot, User, Plus, Trash2, Moon, Sun, Shield, Zap, Search, Accessibility, Bug, ChevronLeft, ChevronRight, BarChart3, MessageSquare, Settings, RefreshCw, Code, FileCode, AlertTriangle, CheckCircle, Clock, Upload, Download, Mail, Bell, Activity, Server, Database, Wifi, X, FileText, Cpu, HardDrive, Sparkles, Brain, Eye, Lock, Globe, Terminal, Play } from "lucide-react";

// Initialize Sentry for Frontend
Sentry.init({
  dsn: "https://e202ac42b34485f50afa83f17ae7158f@o4510681867354112.ingest.de.sentry.io/4510681930203216",
  integrations: [
    Sentry.browserTracingIntegration(),
    Sentry.replayIntegration(),
  ],
  tracesSampleRate: 1.0,
  replaysSessionSampleRate: 0.1,
  replaysOnErrorSampleRate: 1.0,
  environment: "production",
});

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

// Markdown renderer with syntax highlighting
const renderMarkdown = (text) => {
  if (!text) return "";
  
  // Code blocks with language
  let html = text.replace(/```(\w+)?\n([\s\S]*?)```/g, (match, lang, code) => {
    const language = lang || 'code';
    return `<pre class="bg-gray-900 rounded-lg p-4 my-3 overflow-x-auto border border-gray-700"><div class="text-xs text-purple-400 mb-2">${language}</div><code class="text-green-400 text-sm">${code.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</code></pre>`;
  });
  
  // Inline code
  html = html.replace(/`([^`]+)`/g, '<code class="bg-gray-700 px-1.5 py-0.5 rounded text-pink-400 text-sm">$1</code>');
  
  // Headers
  html = html.replace(/^### (.*)$/gm, '<h3 class="text-lg font-bold mt-4 mb-2 text-purple-400">$1</h3>');
  html = html.replace(/^## (.*)$/gm, '<h2 class="text-xl font-bold mt-4 mb-2 text-purple-400">$1</h2>');
  html = html.replace(/^# (.*)$/gm, '<h1 class="text-2xl font-bold mt-4 mb-2 text-purple-400">$1</h1>');
  
  // Bold and italic
  html = html.replace(/\*\*([^*]+)\*\*/g, '<strong class="font-bold text-white">$1</strong>');
  html = html.replace(/\*([^*]+)\*/g, '<em class="italic">$1</em>');
  
  // Links
  html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" class="text-purple-400 hover:underline">$1</a>');
  
  // Lists
  html = html.replace(/^- (.*)$/gm, '<li class="ml-4 flex items-start gap-2"><span class="text-purple-400">•</span><span>$1</span></li>');
  html = html.replace(/^\d+\. (.*)$/gm, '<li class="ml-4">$1</li>');
  
  // Horizontal rules
  html = html.replace(/^---$/gm, '<hr class="border-gray-700 my-4" />');
  
  // Tables (basic)
  html = html.replace(/\|(.+)\|/g, (match, content) => {
    const cells = content.split('|').map(cell => `<td class="border border-gray-700 px-3 py-1">${cell.trim()}</td>`).join('');
    return `<tr>${cells}</tr>`;
  });
  
  // Line breaks
  html = html.replace(/\n/g, '<br/>');
  
  return html;
};

// Quick action suggestions for the chat
const quickActions = [
  { icon: Bug, label: "Analyser un bug", prompt: "J'ai un bug dans mon code, peux-tu m'aider à le résoudre ?" },
  { icon: Shield, label: "Audit sécurité", prompt: "Peux-tu faire un audit de sécurité de mon code ?" },
  { icon: Zap, label: "Optimiser performance", prompt: "Comment puis-je optimiser les performances de mon application ?" },
  { icon: Search, label: "Améliorer SEO", prompt: "Quelles sont les meilleures pratiques SEO pour mon site ?" },
  { icon: Accessibility, label: "Check accessibilité", prompt: "Mon site est-il accessible ? Que dois-je améliorer ?" },
  { icon: Code, label: "Review de code", prompt: "Peux-tu faire une review de mon code et suggérer des améliorations ?" },
];

// Chat Component
const ChatView = ({ conversations, currentConversation, setCurrentConversation, messages, setMessages, onNewConversation, onDeleteConversation, onSendMessage, loading }) => {
  const [input, setInput] = useState("");
  const [modelPreference, setModelPreference] = useState("gpt");
  const messagesEndRef = useRef(null);
  const textareaRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 200) + "px";
    }
  }, [input]);

  const handleSend = () => {
    if (!input.trim() || loading) return;
    onSendMessage(input, modelPreference);
    setInput("");
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleQuickAction = (prompt) => {
    setInput(prompt);
    textareaRef.current?.focus();
  };

  return (
    <div className="flex h-full" data-testid="chat-view">
      {/* Sidebar - Conversations */}
      <div className="w-72 bg-gray-900/50 backdrop-blur-sm border-r border-gray-800 flex flex-col">
        <div className="p-4">
          <button
            onClick={onNewConversation}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white py-3 px-4 rounded-xl transition-all shadow-lg shadow-purple-500/25"
            data-testid="new-conversation-btn"
          >
            <Plus size={18} />
            Nouvelle conversation
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto px-2 space-y-1">
          {conversations.length === 0 ? (
            <div className="text-center text-gray-500 py-8 px-4">
              <MessageSquare size={32} className="mx-auto mb-2 opacity-50" />
              <p className="text-sm">Aucune conversation</p>
            </div>
          ) : (
            conversations.map((conv) => (
              <div
                key={conv.id}
                className={`group flex items-center justify-between p-3 rounded-xl cursor-pointer transition-all ${
                  currentConversation?.id === conv.id
                    ? "bg-gradient-to-r from-purple-600/30 to-pink-600/30 border border-purple-500/50"
                    : "hover:bg-gray-800/50"
                }`}
                onClick={() => setCurrentConversation(conv)}
                data-testid={`conversation-${conv.id}`}
              >
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                    currentConversation?.id === conv.id ? "bg-purple-500" : "bg-gray-700"
                  }`}>
                    <MessageSquare size={14} className="text-white" />
                  </div>
                  <span className="truncate text-sm">{conv.title}</span>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteConversation(conv.id);
                  }}
                  className="opacity-0 group-hover:opacity-100 p-1.5 hover:bg-red-600/30 rounded-lg transition-all"
                  data-testid={`delete-conv-${conv.id}`}
                >
                  <Trash2 size={14} className="text-red-400" />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Model Info */}
        <div className="p-4 border-t border-gray-800">
          <div className="text-xs text-gray-500 mb-2">Modèles disponibles</div>
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="text-gray-400">GPT-5.2 - Raisonnement</span>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <span className="text-gray-400">Claude 4.5 - Code</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950">
        {/* Chat Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-800 bg-gray-900/50 backdrop-blur-sm">
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center shadow-lg shadow-purple-500/30">
                <Bot size={26} className="text-white" />
              </div>
              <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-gray-900"></div>
            </div>
            <div>
              <h2 className="font-bold text-lg flex items-center gap-2">
                KIM
                <Sparkles size={16} className="text-yellow-400" />
              </h2>
              <p className="text-xs text-gray-400">Agent IA de Maintenance Web • En ligne</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-gray-800 rounded-xl px-3 py-2">
              <Brain size={16} className="text-purple-400" />
              <select
                value={modelPreference}
                onChange={(e) => setModelPreference(e.target.value)}
                className="bg-transparent border-none text-sm focus:outline-none cursor-pointer"
                data-testid="model-selector"
              >
                <option value="gpt">GPT-5.2 (Raisonnement)</option>
                <option value="claude">Claude 4.5 (Analyse code)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {messages.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center">
              <div className="relative mb-6">
                <div className="w-24 h-24 bg-gradient-to-br from-purple-500 to-pink-500 rounded-3xl flex items-center justify-center shadow-2xl shadow-purple-500/30">
                  <Bot size={48} className="text-white" />
                </div>
                <div className="absolute -top-2 -right-2">
                  <Sparkles size={24} className="text-yellow-400" />
                </div>
              </div>
              
              <h3 className="text-2xl font-bold mb-2">Bonjour ! Je suis KIM 👋</h3>
              <p className="text-gray-400 text-center max-w-lg mb-8">
                Votre agent IA expert en maintenance web. Je peux analyser votre code, 
                diagnostiquer des problèmes et vous aider à optimiser votre site.
              </p>
              
              {/* Quick Actions */}
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3 max-w-2xl">
                {quickActions.map((action, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleQuickAction(action.prompt)}
                    className="flex items-center gap-3 bg-gray-800/50 hover:bg-gray-800 border border-gray-700 hover:border-purple-500/50 rounded-xl p-4 transition-all group"
                  >
                    <action.icon size={20} className="text-purple-400 group-hover:text-purple-300" />
                    <span className="text-sm text-gray-300 group-hover:text-white">{action.label}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
          
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-4 ${msg.role === "user" ? "justify-end" : "justify-start"}`}
              data-testid={`message-${msg.id}`}
            >
              {msg.role === "assistant" && (
                <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg shadow-purple-500/20">
                  <Bot size={20} className="text-white" />
                </div>
              )}
              
              <div
                className={`max-w-[75%] rounded-2xl px-5 py-4 ${
                  msg.role === "user"
                    ? "bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg shadow-purple-500/20"
                    : "bg-gray-800/80 text-gray-100 border border-gray-700"
                }`}
              >
                {msg.role === "assistant" ? (
                  <div
                    className="prose prose-invert prose-sm max-w-none"
                    dangerouslySetInnerHTML={{ __html: renderMarkdown(msg.content) }}
                  />
                ) : (
                  <p className="whitespace-pre-wrap">{msg.content}</p>
                )}
                {msg.model_used && (
                  <div className="flex items-center gap-2 text-xs text-gray-400 mt-3 pt-3 border-t border-gray-700">
                    <Brain size={12} />
                    {msg.model_used}
                  </div>
                )}
              </div>
              
              {msg.role === "user" && (
                <div className="w-10 h-10 bg-gray-700 rounded-xl flex items-center justify-center flex-shrink-0">
                  <User size={20} className="text-gray-300" />
                </div>
              )}
            </div>
          ))}
          
          {loading && (
            <div className="flex gap-4">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center shadow-lg shadow-purple-500/20">
                <Bot size={20} className="text-white" />
              </div>
              <div className="bg-gray-800/80 rounded-2xl px-5 py-4 border border-gray-700">
                <div className="flex items-center gap-3">
                  <div className="flex gap-1">
                    <div className="w-2.5 h-2.5 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                    <div className="w-2.5 h-2.5 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                    <div className="w-2.5 h-2.5 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                  </div>
                  <span className="text-sm text-gray-400">KIM réfléchit...</span>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-4 border-t border-gray-800 bg-gray-900/50 backdrop-blur-sm">
          <div className="flex gap-3 items-end">
            <div className="flex-1 relative">
              <textarea
                ref={textareaRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Décrivez votre problème ou collez du code..."
                className="w-full bg-gray-800 border border-gray-700 rounded-2xl px-5 py-4 pr-12 resize-none focus:outline-none focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 min-h-[56px] max-h-[200px] transition-all"
                rows={1}
                data-testid="chat-input"
              />
              <div className="absolute right-3 bottom-3 text-xs text-gray-500">
                {input.length > 0 && `${input.length} caractères`}
              </div>
            </div>
            <button
              onClick={handleSend}
              disabled={!input.trim() || loading}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 disabled:from-gray-700 disabled:to-gray-700 disabled:cursor-not-allowed text-white p-4 rounded-2xl transition-all shadow-lg shadow-purple-500/25 disabled:shadow-none"
              data-testid="send-btn"
            >
              <Send size={22} />
            </button>
          </div>
          <div className="flex items-center justify-between mt-2 px-2">
            <p className="text-xs text-gray-500">
              Entrée pour envoyer • Shift+Entrée pour nouvelle ligne
            </p>
            <p className="text-xs text-gray-500 flex items-center gap-1">
              <Lock size={10} /> Conversation sécurisée
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

// Dashboard Component
const DashboardView = ({ stats, analyses, onRunAnalysis, loadingAnalysis, onRefresh }) => {
  const [codeInput, setCodeInput] = useState("");
  const [selectedType, setSelectedType] = useState("all");
  const [uploadFile, setUploadFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);

  const scoreColor = (score) => {
    if (score >= 80) return "text-green-400";
    if (score >= 60) return "text-yellow-400";
    return "text-red-400";
  };

  const scoreColorBg = (score) => {
    if (score >= 80) return "from-green-500/20 to-green-500/5 border-green-500/30";
    if (score >= 60) return "from-yellow-500/20 to-yellow-500/5 border-yellow-500/30";
    return "from-red-500/20 to-red-500/5 border-red-500/30";
  };

  const analysisTypes = [
    { id: "all", label: "Analyse complète", icon: BarChart3, desc: "Tous les aspects" },
    { id: "security", label: "Sécurité", icon: Shield, desc: "Vulnérabilités" },
    { id: "performance", label: "Performance", icon: Zap, desc: "Optimisation" },
    { id: "seo", label: "SEO", icon: Search, desc: "Référencement" },
    { id: "accessibility", label: "Accessibilité", icon: Accessibility, desc: "WCAG" },
    { id: "bugs", label: "Bugs", icon: Bug, desc: "Erreurs" },
  ];

  const handleFileUpload = async () => {
    if (!uploadFile) return;
    setUploading(true);
    
    try {
      const formData = new FormData();
      formData.append("file", uploadFile);
      formData.append("analysis_type", selectedType === "all" ? "bugs" : selectedType);
      
      await axios.post(`${API}/upload-analyze`, formData, {
        headers: { "Content-Type": "multipart/form-data" }
      });
      
      setUploadFile(null);
      if (fileInputRef.current) fileInputRef.current.value = "";
      
      setTimeout(() => {
        onRefresh();
      }, 3000);
      
    } catch (error) {
      console.error("Upload error:", error);
      Sentry.captureException(error);
      alert("Erreur lors de l'upload du fichier");
    } finally {
      setUploading(false);
    }
  };

  const handleExportPDF = async (analysisId) => {
    try {
      const response = await axios.get(`${API}/analyses/${analysisId}/pdf`, {
        responseType: "blob"
      });
      
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `kim_report_${analysisId.slice(0, 8)}.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } catch (error) {
      console.error("PDF export error:", error);
      Sentry.captureException(error);
      alert("Erreur lors de l'export PDF");
    }
  };

  const avgScore = Math.round((stats.security_score + stats.performance_score + stats.seo_score + stats.accessibility_score) / 4);

  return (
    <div className="p-6 overflow-y-auto h-full bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950" data-testid="dashboard-view">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2 flex items-center gap-3">
              <BarChart3 className="text-purple-400" />
              Dashboard
            </h1>
            <p className="text-gray-400">Vue d'ensemble de la santé de votre site web</p>
          </div>
          <button
            onClick={onRefresh}
            className="flex items-center gap-2 bg-gray-800 hover:bg-gray-700 px-4 py-2 rounded-xl transition-colors border border-gray-700"
          >
            <RefreshCw size={18} />
            Actualiser
          </button>
        </div>

        {/* Global Score */}
        <div className="mb-8 bg-gradient-to-r from-purple-600/20 to-pink-600/20 border border-purple-500/30 rounded-2xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg text-gray-300 mb-1">Score Global de Santé</h2>
              <p className="text-sm text-gray-500">Moyenne de tous les indicateurs</p>
            </div>
            <div className="text-right">
              <div className={`text-5xl font-bold ${scoreColor(avgScore)}`}>{avgScore}%</div>
              <p className={`text-sm ${avgScore >= 80 ? 'text-green-400' : avgScore >= 60 ? 'text-yellow-400' : 'text-red-400'}`}>
                {avgScore >= 80 ? '✅ Excellent' : avgScore >= 60 ? '⚠️ Acceptable' : '❌ À améliorer'}
              </p>
            </div>
          </div>
        </div>

        {/* Score Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            { label: "Sécurité", score: stats.security_score, icon: Shield, color: "red" },
            { label: "Performance", score: stats.performance_score, icon: Zap, color: "yellow" },
            { label: "SEO", score: stats.seo_score, icon: Search, color: "blue" },
            { label: "Accessibilité", score: stats.accessibility_score, icon: Accessibility, color: "green" },
          ].map((item) => (
            <div
              key={item.label}
              className={`bg-gradient-to-br ${scoreColorBg(item.score)} border rounded-2xl p-5 hover:scale-[1.02] transition-transform cursor-pointer`}
              data-testid={`score-card-${item.label.toLowerCase()}`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className={`p-2 rounded-xl bg-gray-800/50`}>
                  <item.icon size={20} className="text-gray-300" />
                </div>
                <span className={`text-3xl font-bold ${scoreColor(item.score)}`}>
                  {item.score}%
                </span>
              </div>
              <p className="text-gray-300 font-medium">{item.label}</p>
              <div className="mt-3 bg-gray-800 rounded-full h-2 overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-1000 ${
                    item.score >= 80 ? "bg-green-500" : item.score >= 60 ? "bg-yellow-500" : "bg-red-500"
                  }`}
                  style={{ width: `${item.score}%` }}
                />
              </div>
            </div>
          ))}
        </div>

        {/* Stats Summary */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6 hover:border-purple-500/30 transition-colors">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 bg-purple-500/20 rounded-xl">
                <MessageSquare className="text-purple-400" size={20} />
              </div>
              <span className="text-gray-400">Total conversations</span>
            </div>
            <p className="text-4xl font-bold">{stats.total_conversations}</p>
          </div>
          <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6 hover:border-purple-500/30 transition-colors">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 bg-purple-500/20 rounded-xl">
                <BarChart3 className="text-purple-400" size={20} />
              </div>
              <span className="text-gray-400">Analyses effectuées</span>
            </div>
            <p className="text-4xl font-bold">{stats.total_analyses}</p>
          </div>
        </div>

        {/* File Upload Section */}
        <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Upload className="text-purple-400" />
            Upload de fichier pour analyse
          </h2>
          
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <input
                ref={fileInputRef}
                type="file"
                accept=".py,.js,.jsx,.ts,.tsx,.html,.css,.json,.php,.java,.c,.cpp,.go,.rs,.rb,.vue,.svelte"
                onChange={(e) => setUploadFile(e.target.files[0])}
                className="hidden"
                id="file-upload"
              />
              <label
                htmlFor="file-upload"
                className={`flex items-center justify-center gap-3 w-full p-6 border-2 border-dashed rounded-2xl cursor-pointer transition-all ${
                  uploadFile 
                    ? "border-purple-500 bg-purple-500/10" 
                    : "border-gray-700 hover:border-purple-500 hover:bg-gray-800/50"
                }`}
              >
                <FileText size={24} className={uploadFile ? "text-purple-400" : "text-gray-400"} />
                <span className={uploadFile ? "text-purple-400" : "text-gray-400"}>
                  {uploadFile ? `📄 ${uploadFile.name}` : "Cliquez ou glissez un fichier"}
                </span>
              </label>
              <p className="text-xs text-gray-500 mt-2">
                Formats: .py, .js, .jsx, .ts, .tsx, .html, .css, .json, .php, .java, etc.
              </p>
            </div>
            
            <button
              onClick={handleFileUpload}
              disabled={!uploadFile || uploading}
              className="flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 disabled:from-gray-700 disabled:to-gray-700 text-white px-6 py-4 rounded-xl transition-all min-w-[180px] shadow-lg shadow-purple-500/25 disabled:shadow-none"
              data-testid="upload-analyze-btn"
            >
              {uploading ? (
                <>
                  <RefreshCw size={18} className="animate-spin" />
                  Analyse...
                </>
              ) : (
                <>
                  <Play size={18} />
                  Analyser
                </>
              )}
            </button>
          </div>
        </div>

        {/* Analysis Section */}
        <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Terminal className="text-purple-400" />
            Lancer une analyse de code
          </h2>
          
          {/* Analysis Type Selector */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-4">
            {analysisTypes.map((type) => (
              <button
                key={type.id}
                onClick={() => setSelectedType(type.id)}
                className={`flex flex-col items-center gap-2 p-4 rounded-xl transition-all ${
                  selectedType === type.id
                    ? "bg-gradient-to-br from-purple-600 to-pink-600 text-white shadow-lg shadow-purple-500/25"
                    : "bg-gray-800/50 hover:bg-gray-800 text-gray-300 border border-gray-700"
                }`}
                data-testid={`analysis-type-${type.id}`}
              >
                <type.icon size={20} />
                <span className="text-xs font-medium">{type.label}</span>
              </button>
            ))}
          </div>
          
          {/* Code Input */}
          <textarea
            value={codeInput}
            onChange={(e) => setCodeInput(e.target.value)}
            placeholder="// Collez votre code ici pour analyse...&#10;function example() {&#10;  // votre code&#10;}"
            className="w-full bg-gray-800/50 border border-gray-700 rounded-xl px-4 py-3 resize-none focus:outline-none focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 h-48 font-mono text-sm mb-4 transition-all"
            data-testid="code-input"
          />
          
          <button
            onClick={() => onRunAnalysis(selectedType, codeInput)}
            disabled={loadingAnalysis}
            className="flex items-center gap-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 disabled:from-gray-700 disabled:to-gray-700 text-white px-6 py-3 rounded-xl transition-all shadow-lg shadow-purple-500/25 disabled:shadow-none"
            data-testid="run-analysis-btn"
          >
            {loadingAnalysis ? (
              <>
                <RefreshCw size={18} className="animate-spin" />
                Analyse en cours...
              </>
            ) : (
              <>
                <Eye size={18} />
                Analyser le code
              </>
            )}
          </button>
        </div>

        {/* Recent Analyses */}
        <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <FileCode className="text-purple-400" />
            Analyses récentes
          </h2>
          
          {analyses.length === 0 ? (
            <div className="text-center py-12">
              <FileCode size={48} className="mx-auto mb-4 text-gray-600" />
              <p className="text-gray-400">Aucune analyse effectuée</p>
              <p className="text-sm text-gray-500">Lancez votre première analyse ci-dessus</p>
            </div>
          ) : (
            <div className="space-y-3">
              {analyses.slice(0, 10).map((analysis) => (
                <div
                  key={analysis.id}
                  className="bg-gray-800/50 rounded-xl p-4 flex items-center justify-between hover:bg-gray-800 transition-colors border border-gray-700/50"
                  data-testid={`analysis-${analysis.id}`}
                >
                  <div className="flex items-center gap-4">
                    <div className={`p-2 rounded-xl ${
                      analysis.status === "completed" ? "bg-green-500/20" : 
                      analysis.status === "failed" ? "bg-red-500/20" : "bg-yellow-500/20"
                    }`}>
                      {analysis.status === "completed" ? (
                        <CheckCircle className="text-green-400" size={20} />
                      ) : analysis.status === "failed" ? (
                        <AlertTriangle className="text-red-400" size={20} />
                      ) : (
                        <Clock className="text-yellow-400 animate-pulse" size={20} />
                      )}
                    </div>
                    <div>
                      <p className="font-medium capitalize flex items-center gap-2">
                        {analysis.type}
                        {analysis.filename && (
                          <span className="text-gray-400 text-sm font-normal">
                            • {analysis.filename}
                          </span>
                        )}
                      </p>
                      <p className="text-sm text-gray-500">
                        {new Date(analysis.created_at).toLocaleString("fr-FR")}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    {analysis.score !== null && analysis.score !== undefined && (
                      <div className={`text-2xl font-bold ${scoreColor(analysis.score)}`}>
                        {analysis.score}%
                      </div>
                    )}
                    
                    {analysis.status === "completed" && (
                      <button
                        onClick={() => handleExportPDF(analysis.id)}
                        className="flex items-center gap-2 bg-gray-700 hover:bg-gray-600 px-4 py-2 rounded-xl transition-colors text-sm"
                        title="Exporter en PDF"
                      >
                        <Download size={16} />
                        PDF
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent Issues */}
        {stats.recent_issues && stats.recent_issues.length > 0 && (
          <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6 mt-8">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <AlertTriangle className="text-yellow-400" />
              Problèmes détectés
            </h2>
            <div className="space-y-2">
              {stats.recent_issues.map((issue, idx) => {
                const issueText = typeof issue.issue === 'object' 
                  ? (issue.issue?.description || issue.issue?.issue || JSON.stringify(issue.issue))
                  : issue.issue;
                return (
                  <div key={idx} className="bg-gray-800/50 rounded-xl p-4 flex items-start gap-3 border border-gray-700/50">
                    <div className="p-1.5 bg-orange-500/20 rounded-lg">
                      <Bug className="text-orange-400" size={14} />
                    </div>
                    <div className="flex-1">
                      <span className="text-xs text-purple-400 uppercase font-medium">{issue.type}</span>
                      <p className="text-sm text-gray-300 mt-1">{issueText}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// Settings Component
const SettingsView = ({ onRefresh }) => {
  const [alertConfigs, setAlertConfigs] = useState([]);
  const [newEmail, setNewEmail] = useState("");
  const [newThreshold, setNewThreshold] = useState(50);
  const [selectedAlertTypes, setSelectedAlertTypes] = useState(["security", "bugs"]);
  const [testEmail, setTestEmail] = useState("");
  const [sending, setSending] = useState(false);
  const [monitoring, setMonitoring] = useState(null);

  useEffect(() => {
    fetchAlertConfigs();
    fetchMonitoring();
  }, []);

  const fetchAlertConfigs = async () => {
    try {
      const response = await axios.get(`${API}/alerts/config`);
      setAlertConfigs(response.data);
    } catch (error) {
      console.error("Error fetching alert configs:", error);
    }
  };

  const fetchMonitoring = async () => {
    try {
      const response = await axios.get(`${API}/monitoring`);
      setMonitoring(response.data);
    } catch (error) {
      console.error("Error fetching monitoring:", error);
    }
  };

  const handleAddAlertConfig = async () => {
    if (!newEmail) return;
    
    try {
      await axios.post(`${API}/alerts/config`, {
        email: newEmail,
        alert_types: selectedAlertTypes,
        threshold: newThreshold
      });
      setNewEmail("");
      fetchAlertConfigs();
    } catch (error) {
      console.error("Error adding alert config:", error);
      alert("Erreur lors de l'ajout de la configuration");
    }
  };

  const handleDeleteConfig = async (configId) => {
    try {
      await axios.delete(`${API}/alerts/config/${configId}`);
      fetchAlertConfigs();
    } catch (error) {
      console.error("Error deleting config:", error);
    }
  };

  const handleTestEmail = async () => {
    if (!testEmail) return;
    setSending(true);
    
    try {
      await axios.post(`${API}/alerts/test`, {
        to_email: testEmail,
        subject: "Test KIM Agent",
        message: "Ceci est un email de test. Votre configuration SMTP fonctionne correctement ! 🎉"
      });
      alert("Email envoyé avec succès !");
    } catch (error) {
      console.error("Error sending test email:", error);
      alert("Erreur lors de l'envoi. Vérifiez la configuration SMTP dans le fichier .env");
    } finally {
      setSending(false);
    }
  };

  const alertTypes = [
    { id: "security", label: "Sécurité", icon: Shield },
    { id: "performance", label: "Performance", icon: Zap },
    { id: "seo", label: "SEO", icon: Search },
    { id: "accessibility", label: "Accessibilité", icon: Accessibility },
    { id: "bugs", label: "Bugs", icon: Bug },
  ];

  return (
    <div className="p-6 overflow-y-auto h-full bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950" data-testid="settings-view">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-2 flex items-center gap-3">
          <Settings className="text-purple-400" />
          Paramètres
        </h1>
        <p className="text-gray-400 mb-8">Configuration des alertes et du monitoring</p>

        {/* Email Alerts Section */}
        <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Mail className="text-purple-400" />
            Configuration des alertes email
          </h2>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-gray-400 mb-2">Email de destination</label>
              <input
                type="email"
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
                placeholder="votre@email.com"
                className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 focus:outline-none focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all"
              />
            </div>
            
            <div>
              <label className="block text-sm text-gray-400 mb-2">Types d'alertes</label>
              <div className="flex flex-wrap gap-2">
                {alertTypes.map((type) => (
                  <button
                    key={type.id}
                    onClick={() => {
                      if (selectedAlertTypes.includes(type.id)) {
                        setSelectedAlertTypes(selectedAlertTypes.filter(t => t !== type.id));
                      } else {
                        setSelectedAlertTypes([...selectedAlertTypes, type.id]);
                      }
                    }}
                    className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm transition-all ${
                      selectedAlertTypes.includes(type.id)
                        ? "bg-purple-600 text-white shadow-lg shadow-purple-500/25"
                        : "bg-gray-800 text-gray-400 hover:bg-gray-700 border border-gray-700"
                    }`}
                  >
                    <type.icon size={14} />
                    {type.label}
                  </button>
                ))}
              </div>
            </div>
            
            <div>
              <label className="block text-sm text-gray-400 mb-2">
                Seuil d'alerte: <span className="text-purple-400 font-bold">{newThreshold}%</span>
              </label>
              <input
                type="range"
                min="10"
                max="90"
                value={newThreshold}
                onChange={(e) => setNewThreshold(parseInt(e.target.value))}
                className="w-full accent-purple-500"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>10% (Plus d'alertes)</span>
                <span>90% (Moins d'alertes)</span>
              </div>
            </div>
            
            <button
              onClick={handleAddAlertConfig}
              disabled={!newEmail}
              className="flex items-center gap-2 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 disabled:from-gray-700 disabled:to-gray-700 text-white px-5 py-2.5 rounded-xl transition-all shadow-lg shadow-purple-500/25 disabled:shadow-none"
            >
              <Bell size={18} />
              Ajouter la configuration
            </button>
          </div>
          
          {/* Existing Configs */}
          {alertConfigs.length > 0 && (
            <div className="mt-6 pt-6 border-t border-gray-700">
              <h3 className="text-lg font-medium mb-4">Configurations actives</h3>
              <div className="space-y-2">
                {alertConfigs.map((config) => (
                  <div key={config.id} className="flex items-center justify-between bg-gray-800/50 rounded-xl p-4 border border-gray-700">
                    <div>
                      <p className="font-medium">{config.email}</p>
                      <p className="text-sm text-gray-400">
                        Seuil: {config.threshold}% | Types: {config.alert_types?.join(", ")}
                      </p>
                    </div>
                    <button
                      onClick={() => handleDeleteConfig(config.id)}
                      className="p-2 hover:bg-red-600/30 rounded-xl transition-colors"
                    >
                      <Trash2 size={16} className="text-red-400" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Test Email Section */}
        <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Send className="text-purple-400" />
            Tester l'envoi d'email
          </h2>
          
          <div className="flex gap-4">
            <input
              type="email"
              value={testEmail}
              onChange={(e) => setTestEmail(e.target.value)}
              placeholder="Email de test"
              className="flex-1 bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 focus:outline-none focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 transition-all"
            />
            <button
              onClick={handleTestEmail}
              disabled={!testEmail || sending}
              className="flex items-center gap-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-700 text-white px-5 py-3 rounded-xl transition-colors"
            >
              {sending ? <RefreshCw size={18} className="animate-spin" /> : <Send size={18} />}
              Envoyer
            </button>
          </div>
        </div>

        {/* Monitoring Section */}
        <div className="bg-gray-900/50 border border-gray-800 rounded-2xl p-6">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Activity className="text-purple-400" />
            Monitoring (Sentry & DataDog)
          </h2>
          
          {monitoring ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Sentry Status */}
              <div className="bg-gray-800/50 rounded-xl p-5 border border-gray-700">
                <div className="flex items-center gap-3 mb-4">
                  <div className={`w-3 h-3 rounded-full ${monitoring.sentry.connected ? 'bg-green-500 shadow-lg shadow-green-500/50' : 'bg-yellow-500'}`} />
                  <h3 className="font-semibold">Sentry</h3>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${monitoring.sentry.connected ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'}`}>
                    {monitoring.sentry.connected ? '✓ Connecté' : 'Demo'}
                  </span>
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Erreurs (24h)</span>
                    <span className="text-red-400 font-medium">{monitoring.sentry.errors_24h}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Erreurs (7j)</span>
                    <span className="text-orange-400 font-medium">{monitoring.sentry.errors_7d}</span>
                  </div>
                </div>
                {monitoring.sentry.top_errors?.length > 0 && (
                  <div className="mt-4 pt-4 border-t border-gray-700">
                    <p className="text-xs text-gray-400 mb-2">Top erreurs:</p>
                    {monitoring.sentry.top_errors.map((err, idx) => (
                      <div key={idx} className="flex justify-between text-xs py-1">
                        <span className="text-gray-300 font-mono">{err.type}</span>
                        <span className="text-gray-500">{err.count}x</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* DataDog Status */}
              <div className="bg-gray-800/50 rounded-xl p-5 border border-gray-700">
                <div className="flex items-center gap-3 mb-4">
                  <div className={`w-3 h-3 rounded-full ${monitoring.datadog.connected ? 'bg-green-500 shadow-lg shadow-green-500/50' : 'bg-yellow-500'}`} />
                  <h3 className="font-semibold">DataDog</h3>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${monitoring.datadog.connected ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'}`}>
                    {monitoring.datadog.connected ? '✓ Connecté' : 'Demo'}
                  </span>
                </div>
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-400 flex items-center gap-1"><Cpu size={12} /> CPU</span>
                      <span className="font-medium">{monitoring.datadog.cpu_usage}%</span>
                    </div>
                    <div className="bg-gray-700 rounded-full h-2 overflow-hidden">
                      <div className="bg-blue-500 h-full transition-all" style={{ width: `${monitoring.datadog.cpu_usage}%` }} />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-400 flex items-center gap-1"><HardDrive size={12} /> Mémoire</span>
                      <span className="font-medium">{monitoring.datadog.memory_usage}%</span>
                    </div>
                    <div className="bg-gray-700 rounded-full h-2 overflow-hidden">
                      <div className="bg-purple-500 h-full transition-all" style={{ width: `${monitoring.datadog.memory_usage}%` }} />
                    </div>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Requêtes/min</span>
                    <span className="font-medium">{monitoring.datadog.request_rate}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Temps réponse</span>
                    <span className="font-medium">{monitoring.datadog.avg_response_time}ms</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Uptime</span>
                    <span className="text-green-400 font-medium">{monitoring.datadog.uptime}%</span>
                  </div>
                </div>
              </div>

              {/* Health Status */}
              <div className="bg-gray-800/50 rounded-xl p-5 border border-gray-700 md:col-span-2">
                <h3 className="font-semibold mb-4 flex items-center gap-2">
                  <Server size={18} />
                  État des services
                </h3>
                <div className="flex flex-wrap gap-3">
                  {Object.entries(monitoring.health).map(([service, status]) => (
                    <div key={service} className="flex items-center gap-2 bg-gray-700/50 rounded-xl px-4 py-2 border border-gray-600">
                      <div className={`w-2 h-2 rounded-full ${status === 'healthy' || status === 'configured' ? 'bg-green-500' : 'bg-yellow-500'}`} />
                      <span className="capitalize text-sm font-medium">{service}</span>
                      <span className={`text-xs ${status === 'healthy' || status === 'configured' ? 'text-green-400' : 'text-yellow-400'}`}>
                        ({status})
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center py-12">
              <RefreshCw className="animate-spin text-purple-400" size={32} />
            </div>
          )}
          
          <div className="mt-6 p-4 bg-purple-500/10 rounded-xl border border-purple-500/30">
            <p className="text-sm text-gray-300">
              <Sparkles size={14} className="inline mr-2 text-yellow-400" />
              <strong>Sentry est connecté !</strong> Les erreurs de votre application sont maintenant capturées automatiquement.
              Pour DataDog, ajoutez votre API Key dans le fichier <code className="bg-gray-800 px-1.5 py-0.5 rounded text-purple-400">.env</code>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

// Main App with Error Boundary
function App() {
  const [darkMode, setDarkMode] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [currentView, setCurrentView] = useState("chat");
  
  // Chat state
  const [conversations, setConversations] = useState([]);
  const [currentConversation, setCurrentConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  
  // Dashboard state
  const [stats, setStats] = useState({
    total_conversations: 0,
    total_analyses: 0,
    security_score: 85,
    performance_score: 78,
    seo_score: 82,
    accessibility_score: 90,
    recent_issues: []
  });
  const [analyses, setAnalyses] = useState([]);
  const [loadingAnalysis, setLoadingAnalysis] = useState(false);

  const fetchConversations = useCallback(async () => {
    try {
      const response = await axios.get(`${API}/conversations`);
      setConversations(response.data);
    } catch (error) {
      console.error("Error fetching conversations:", error);
      Sentry.captureException(error);
    }
  }, []);

  const fetchMessages = useCallback(async (conversationId) => {
    try {
      const response = await axios.get(`${API}/conversations/${conversationId}/messages`);
      setMessages(response.data);
    } catch (error) {
      console.error("Error fetching messages:", error);
      Sentry.captureException(error);
    }
  }, []);

  const fetchDashboardData = useCallback(async () => {
    try {
      const [statsRes, analysesRes] = await Promise.all([
        axios.get(`${API}/dashboard`),
        axios.get(`${API}/analyses`)
      ]);
      setStats(statsRes.data);
      setAnalyses(analysesRes.data);
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
      Sentry.captureException(error);
    }
  }, []);

  useEffect(() => {
    fetchConversations();
    fetchDashboardData();
  }, [fetchConversations, fetchDashboardData]);

  useEffect(() => {
    if (currentConversation) {
      fetchMessages(currentConversation.id);
    } else {
      setMessages([]);
    }
  }, [currentConversation, fetchMessages]);

  const handleNewConversation = async () => {
    try {
      const response = await axios.post(`${API}/conversations`, {
        title: "Nouvelle conversation"
      });
      setConversations([response.data, ...conversations]);
      setCurrentConversation(response.data);
      setMessages([]);
    } catch (error) {
      console.error("Error creating conversation:", error);
      Sentry.captureException(error);
    }
  };

  const handleDeleteConversation = async (conversationId) => {
    try {
      await axios.delete(`${API}/conversations/${conversationId}`);
      setConversations(conversations.filter(c => c.id !== conversationId));
      if (currentConversation?.id === conversationId) {
        setCurrentConversation(null);
        setMessages([]);
      }
    } catch (error) {
      console.error("Error deleting conversation:", error);
      Sentry.captureException(error);
    }
  };

  const handleSendMessage = async (message, modelPreference) => {
    setLoading(true);
    
    const tempUserMsg = {
      id: `temp-${Date.now()}`,
      role: "user",
      content: message,
      conversation_id: currentConversation?.id
    };
    setMessages(prev => [...prev, tempUserMsg]);
    
    try {
      const response = await axios.post(`${API}/chat`, {
        message,
        conversation_id: currentConversation?.id,
        model_preference: modelPreference
      });
      
      if (!currentConversation || currentConversation.id !== response.data.conversation_id) {
        fetchConversations();
        setCurrentConversation({ id: response.data.conversation_id, title: message.substring(0, 50) });
      }
      
      await fetchMessages(response.data.conversation_id);
      
    } catch (error) {
      console.error("Error sending message:", error);
      Sentry.captureException(error);
      setMessages(prev => prev.filter(m => m.id !== tempUserMsg.id));
    } finally {
      setLoading(false);
    }
  };

  const handleRunAnalysis = async (type, code) => {
    setLoadingAnalysis(true);
    try {
      await axios.post(`${API}/analyze`, {
        type,
        code: code || null
      });
      
      setTimeout(() => {
        fetchDashboardData();
        setLoadingAnalysis(false);
      }, 3000);
      
    } catch (error) {
      console.error("Error running analysis:", error);
      Sentry.captureException(error);
      setLoadingAnalysis(false);
    }
  };

  return (
    <Sentry.ErrorBoundary fallback={<div className="h-screen flex items-center justify-center bg-gray-950 text-white">Une erreur est survenue. Veuillez rafraîchir la page.</div>}>
      <div className={`h-screen flex ${darkMode ? "dark bg-gray-950 text-white" : "bg-white text-gray-900"}`} data-testid="app-container">
        {/* Navigation Sidebar */}
        <div className={`${sidebarOpen ? "w-16" : "w-0"} bg-gray-900/80 backdrop-blur-sm border-r border-gray-800 flex flex-col items-center py-4 transition-all duration-300 overflow-hidden`}>
          <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center mb-8 shadow-lg shadow-purple-500/30">
            <Bot size={24} className="text-white" />
          </div>
          
          <nav className="flex-1 flex flex-col items-center gap-2">
            <button
              onClick={() => setCurrentView("chat")}
              className={`p-3 rounded-xl transition-all ${
                currentView === "chat"
                  ? "bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg shadow-purple-500/30"
                  : "text-gray-400 hover:bg-gray-800 hover:text-white"
              }`}
              title="Chat"
              data-testid="nav-chat"
            >
              <MessageSquare size={22} />
            </button>
            
            <button
              onClick={() => { setCurrentView("dashboard"); fetchDashboardData(); }}
              className={`p-3 rounded-xl transition-all ${
                currentView === "dashboard"
                  ? "bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg shadow-purple-500/30"
                  : "text-gray-400 hover:bg-gray-800 hover:text-white"
              }`}
              title="Dashboard"
              data-testid="nav-dashboard"
            >
              <BarChart3 size={22} />
            </button>
            
            <button
              onClick={() => setCurrentView("settings")}
              className={`p-3 rounded-xl transition-all ${
                currentView === "settings"
                  ? "bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg shadow-purple-500/30"
                  : "text-gray-400 hover:bg-gray-800 hover:text-white"
              }`}
              title="Paramètres"
              data-testid="nav-settings"
            >
              <Settings size={22} />
            </button>
          </nav>
          
          <div className="flex flex-col items-center gap-2">
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="p-3 text-gray-400 hover:bg-gray-800 hover:text-white rounded-xl transition-colors"
              title="Thème"
              data-testid="theme-toggle"
            >
              {darkMode ? <Sun size={22} /> : <Moon size={22} />}
            </button>
          </div>
        </div>

        {/* Toggle Sidebar */}
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="absolute left-0 top-1/2 -translate-y-1/2 bg-gray-800 hover:bg-gray-700 p-1.5 rounded-r-lg text-gray-400 hover:text-white transition-all z-10"
          style={{ left: sidebarOpen ? "64px" : "0" }}
          data-testid="sidebar-toggle"
        >
          {sidebarOpen ? <ChevronLeft size={16} /> : <ChevronRight size={16} />}
        </button>

        {/* Main Content */}
        <div className="flex-1 overflow-hidden">
          {currentView === "chat" ? (
            <ChatView
              conversations={conversations}
              currentConversation={currentConversation}
              setCurrentConversation={setCurrentConversation}
              messages={messages}
              setMessages={setMessages}
              onNewConversation={handleNewConversation}
              onDeleteConversation={handleDeleteConversation}
              onSendMessage={handleSendMessage}
              loading={loading}
            />
          ) : currentView === "dashboard" ? (
            <DashboardView
              stats={stats}
              analyses={analyses}
              onRunAnalysis={handleRunAnalysis}
              loadingAnalysis={loadingAnalysis}
              onRefresh={fetchDashboardData}
            />
          ) : (
            <SettingsView onRefresh={fetchDashboardData} />
          )}
        </div>
      </div>
    </Sentry.ErrorBoundary>
  );
}

export default App;
